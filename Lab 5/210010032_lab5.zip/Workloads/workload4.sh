#!/bin/bash
./arithoh.sh &
./arithoh.sh &
./arithoh.sh &
./fstime.sh &
./syscall.sh &
wait