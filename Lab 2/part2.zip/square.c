#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main(int argcnt, char* argv[]){
    if (argcnt < 2) {
    exit(0);
    }
    
    int m = (atoi(argv[argcnt - 1]));
    int n = m*m;
    printf("Square: Current process id: %d, Current result: %d\n", (int) getpid(), n);

    char* nxtcmd[argcnt];

    for (int i = 0; i < argcnt; i++) {
        nxtcmd[i] = argv[i+1];
    }

    sprintf(nxtcmd[argcnt-2], "%d", n);

    execvp(nxtcmd[0], nxtcmd);
    return 0;
}